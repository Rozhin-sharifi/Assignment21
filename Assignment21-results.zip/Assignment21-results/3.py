import cv2
image=cv2.imread('Assignment21/3.jpg')
image=cv2.cvtColor(image,cv2.COLOR_RGB2GRAY)

(h,w)=image.shape
center=(w/2,h/2)
angle=180
scale=1
M = cv2.getRotationMatrix2D(center, angle, scale)
image = cv2.warpAffine(image, M, (w, h))

cv2.imshow('Picture',image)
cv2.waitKey()